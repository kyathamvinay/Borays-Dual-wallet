import 'package:bip39/bip39.dart' as bip39;
import 'package:web3dart/web3dart.dart';
import 'package:http/http.dart';
import 'package:web3dart/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math';

class WalletApi {
  // Infura API key for Ethereum network access
  static const String _infuraApiKey = '96200534d4d240ad9f0c26bbbb038b64';
  static const String _infuraUrl = 'https://sepolia.infura.io/v3/$_infuraApiKey';
  
  // Create wallet from mnemonic - this was missing!
  static Future<Map<String, String>> createWalletFromMnemonic(String mnemonic) async {
    try {
      // Convert mnemonic to seed
      final seed = bip39.mnemonicToSeed(mnemonic);
      
      // Create a new wallet from the seed
      final wallet = EthPrivateKey.fromHex(bytesToHex(seed.sublist(0, 32)));
      
      // Get the wallet address
      final address = wallet.address.hex;
      
      // Get the private key
      final privateKey = bytesToHex(wallet.privateKey);
      
      // Get the public key
      final publicKey = bytesToHex(privateKeyBytesToPublic(wallet.privateKey));
      
      // Store the wallet data in SharedPreferences for easy access
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('address', address);
      await prefs.setString('privateKey', privateKey);
      await prefs.setString('mnemonic', mnemonic);
      
      return {
        'address': address,
        'privateKey': privateKey,
        'mnemonic': mnemonic,
        'publicKey': publicKey,
      };
    } catch (e) {
      print('Error creating wallet from mnemonic: $e');
      throw Exception('Failed to create wallet from mnemonic: $e');
    }
  }

  // Create a new wallet
  static Future<Map<String, String>> createWallet({String? mnemonic}) async {
    try {
      // Generate a new mnemonic if not provided
      final mnemonicPhrase = mnemonic ?? bip39.generateMnemonic();
      
      // Convert mnemonic to seed
      final seed = bip39.mnemonicToSeed(mnemonicPhrase);
      
      // Create a new wallet from the seed
      final wallet = EthPrivateKey.fromHex(bytesToHex(seed.sublist(0, 32)));
      
      // Get the wallet address
      final address = wallet.address.hex;
      
      // Get the private key
      final privateKey = bytesToHex(wallet.privateKey);
      
      // Get the public key
      final publicKey = bytesToHex(privateKeyBytesToPublic(wallet.privateKey));
      
      // Store the wallet data in SharedPreferences for easy access
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('address', address);
      await prefs.setString('privateKey', privateKey);
      await prefs.setString('mnemonic', mnemonicPhrase);
      
      return {
        'address': address,
        'privateKey': privateKey,
        'mnemonic': mnemonicPhrase,
        'publicKey': publicKey,
      };
    } catch (e) {
      print('Error creating wallet: $e');
      throw Exception('Failed to create wallet: $e');
    }
  }
  
  // Get ETH balance for an address
  static Future<String> getEthBalance(String address) async {
    try {
      final client = Web3Client(_infuraUrl, Client());
      
      // Add a small random delay to avoid rate limiting and ensure fresh data
      await Future.delayed(Duration(milliseconds: 300 + DateTime.now().millisecond % 500));
      
      final balance = await client.getBalance(EthereumAddress.fromHex(address));
      
      // Convert from Wei to ETH
      final ethBalance = balance.getValueInUnit(EtherUnit.ether);
      
      // Format to 6 decimal places
      return ethBalance.toStringAsFixed(6);
    } catch (e) {
      print('Error getting ETH balance: $e');
      throw Exception('Failed to get ETH balance: $e');
    }
  }
  
  // Send a transaction - fixed to use positional parameters
  static Future<String> sendTransaction(
    String privateKey,
    String toAddress,
    String amount,
  ) async {
    try {
      print('Starting transaction process...');
      print('Sending $amount ETH to $toAddress');
      
      // Create credentials from private key
      final credentials = EthPrivateKey.fromHex(privateKey);
      final fromAddress = credentials.address.hex;
      print('Using wallet address: $fromAddress');
      
      // Create Web3 client
      final client = Web3Client(_infuraUrl, Client());
      print('Connected to Ethereum network via Infura');
      
      // Get the current gas price
      final gasPrice = await client.getGasPrice();
      print('Current gas price: ${gasPrice.getValueInUnit(EtherUnit.gwei)} Gwei');
      
      // Calculate increased gas price (110% of current)
      final increasedGasPrice = EtherAmount.inWei(
        gasPrice.getInWei * BigInt.from(110) ~/ BigInt.from(100)
      );
      print('Using increased gas price: ${increasedGasPrice.getValueInUnit(EtherUnit.gwei)} Gwei');
      
      // Convert amount from ETH to Wei with precise calculation
      final amountInEther = double.parse(amount);
      // Use a more precise way to convert to Wei
      final amountInWei = BigInt.from(amountInEther * pow(10, 18));
      print('Amount in Wei: $amountInWei');
      
      // Get nonce for the transaction
      final nonce = await client.getTransactionCount(credentials.address);
      print('Using nonce: $nonce');
      
      // Check sender balance before sending
      final senderBalance = await client.getBalance(credentials.address);
      print('Sender balance: ${senderBalance.getValueInUnit(EtherUnit.ether)} ETH');
      
      // Ensure sender has enough balance
      if (senderBalance.getInWei < amountInWei) {
        throw Exception('Insufficient balance. You have ${senderBalance.getValueInUnit(EtherUnit.ether)} ETH but trying to send $amount ETH');
      }
      
      // Create transaction with proper parameters
      final transaction = Transaction(
        to: EthereumAddress.fromHex(toAddress),
        value: EtherAmount.inWei(amountInWei),
        maxGas: 50000, // Increased gas limit for better reliability
        gasPrice: increasedGasPrice,
        nonce: nonce,
      );
      
      print('Transaction prepared, sending to network...');
      
      // Sign and send the transaction
      final txHash = await client.sendTransaction(
        credentials,
        transaction,
        chainId: 11155111, // Sepolia testnet chain ID
      );
      
      print('Transaction sent! Hash: $txHash');
      print('View on Etherscan: https://sepolia.etherscan.io/tx/$txHash');
      
      // Wait for transaction to be mined with improved timeout handling
      print('Waiting for transaction to be mined...');
      bool mined = false;
      int attempts = 0;
      const maxAttempts = 10; // Increased max attempts
      
      while (!mined && attempts < maxAttempts) {
        try {
          final receipt = await client.getTransactionReceipt(txHash);
          if (receipt != null) {
            if (receipt.status!) {
              mined = true;
              print('Transaction mined successfully!');
              print('Gas used: ${receipt.gasUsed}');
            } else {
              throw Exception('Transaction failed on blockchain');
            }
          } else {
            attempts++;
            print('Waiting for confirmation... Attempt $attempts of $maxAttempts');
            await Future.delayed(const Duration(seconds: 3));
          }
        } catch (e) {
          if (e.toString().contains('Transaction failed')) {
            throw e; // Rethrow if it's our specific error
          }
          attempts++;
          print('Error checking transaction status: $e');
          print('Retrying... Attempt $attempts of $maxAttempts');
          await Future.delayed(const Duration(seconds: 3));
        }
      }
      
      if (!mined) {
        print('Transaction sent but not confirmed within timeout period.');
        print('It may still be processed. Check Etherscan: https://sepolia.etherscan.io/tx/$txHash');
      }
      
      // Return the transaction hash regardless
      return txHash;
    } catch (e) {
      print('Error sending transaction: $e');
      throw Exception('Failed to send transaction: $e');
    }
  }
  
  // Get Etherscan URL for an address
  static String getEtherscanAddressUrl(String address) {
    return 'https://sepolia.etherscan.io/address/$address';
  }
  
  // Get Etherscan URL for a transaction
  static String getEtherscanTxUrl(String txHash) {
    return 'https://sepolia.etherscan.io/tx/$txHash';
  }
  
  // Request testnet ETH from a faucet
  static Future<bool> requestTestnetEth(String address) async {
    try {
      // This is a mock implementation since most faucets require captcha
      // In a real app, you would direct users to a faucet website
      
      print('Requesting testnet ETH for address: $address');
      
      // Simulate a successful faucet request
      await Future.delayed(const Duration(seconds: 2));
      
      return true;
    } catch (e) {
      print('Error requesting testnet ETH: $e');
      return false;
    }
  }
}
