import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:web3_wallet/providers/wallet_provider.dart';
import 'package:web3_wallet/pages/login_page.dart';
import 'package:web3_wallet/theme/app_theme.dart';
import 'package:web3_wallet/pages/set_device_passwords_page.dart';

class ImportWalletPage extends StatefulWidget {
  const ImportWalletPage({Key? key}) : super(key: key);

  @override
  State<ImportWalletPage> createState() => _ImportWalletPageState();
}

class _ImportWalletPageState extends State<ImportWalletPage> {
  final _mnemonicController = TextEditingController();
  bool _isLoading = false;
  String? _errorMessage;
  int? _selectedDeviceType; // 1 for Device 1, 2 for Device 2
  String mnemonicPart = "";

  @override
  void dispose() {
    _mnemonicController.dispose();
    super.dispose();
  }

  Future<void> _verifyDeviceMnemonic() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      mnemonicPart = _mnemonicController.text.trim();
      
      // Validate input
      if (mnemonicPart.isEmpty) {
        setState(() {
          _errorMessage = 'Please enter your device recovery phrase';
          _isLoading = false;
        });
        return;
      }

      if (_selectedDeviceType == null) {
        setState(() {
          _errorMessage = 'Please select your device type';
        _isLoading = false;
        });
        return;
      }

      final words = mnemonicPart.split(' ');
      if (words.length != 12) {
        setState(() {
          _errorMessage = 'Device recovery phrase must be exactly 12 words';
          _isLoading = false;
        });
        return;
      }

      print('🔄 Verifying device mnemonic part...');
      print('📱 Device type: $_selectedDeviceType');
      print('📝 Mnemonic part: "${mnemonicPart.substring(0, 20)}..."');
      
      final walletProvider = Provider.of<WalletProvider>(context, listen: false);
      final verificationResult = await walletProvider.verifyDeviceMnemonicPart(
        mnemonicPart: mnemonicPart,
        deviceType: _selectedDeviceType!,
      );

      if (verificationResult != null) {
        print('✅ Device verification successful!');
        print('📊 Verification result: $verificationResult');
        
        // Check if device has passwords stored in Firebase
        final deviceData = verificationResult['deviceData'] as Map<String, dynamic>?;
        
        if (deviceData != null) {
          final password = deviceData['password'] as String?;
          final transactionPassword = deviceData['transactionPassword'] as String?;
          
          final hasValidPassword = password != null && password.isNotEmpty;
          final hasValidTxPassword = transactionPassword != null && transactionPassword.isNotEmpty;
          
          print('🔑 Device has valid password in Firebase: $hasValidPassword');
          print('🔑 Device has valid transaction password in Firebase: $hasValidTxPassword');
          print('🔍 Password value: "$password"');
          print('🔍 Transaction password value: "$transactionPassword"');
          
          if (mounted) {
            if (hasValidPassword && hasValidTxPassword) {
              // Device has passwords in Firebase - go to login
              print('➡️ Navigating to login page (passwords found in Firebase)');
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => LoginPage(isDevice1: _selectedDeviceType == 1),
                ),
              );
            } else {
              // Device doesn't have passwords - go to setup
              print('➡️ Navigating to password setup (no valid passwords in Firebase)');
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => SetDevicePasswordsPage(
                    isDevice1: _selectedDeviceType == 1,
                    deviceMnemonicPart: mnemonicPart,
                  ),
                ),
              );
            }
          }
        } else {
          print('❌ No device data found in verification result');
          setState(() {
            _errorMessage = 'Device data not found. Please try again.';
            _isLoading = false;
          });
        }
      } else {
        print('❌ Device verification failed');
        setState(() {
          _errorMessage = 'Device not found. Please check your recovery phrase and device type.';
          _isLoading = false;
        });
      }
    } catch (e) {
      print('💥 Error during device verification: $e');
      setState(() {
        _errorMessage = 'Failed to verify device. Please try again.';
        _isLoading = false;
      });
    }
  }

  Widget _buildDeviceSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Select Your Device',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _selectedDeviceType = 1),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _selectedDeviceType == 1 
                        ? AppTheme.neonGreen.withOpacity(0.2)
                        : Colors.black.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _selectedDeviceType == 1 
                          ? AppTheme.neonGreen 
                          : Colors.white.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        Icons.smartphone,
                        color: _selectedDeviceType == 1 
                            ? AppTheme.neonGreen 
                            : Colors.white70,
                        size: 32,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Device 1',
                        style: TextStyle(
                          color: _selectedDeviceType == 1 
                              ? AppTheme.neonGreen 
                              : Colors.white70,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'First 12 words',
                        style: TextStyle(
                          color: _selectedDeviceType == 1 
                              ? AppTheme.neonGreen.withOpacity(0.8)
                              : Colors.white54,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _selectedDeviceType = 2),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _selectedDeviceType == 2 
                        ? AppTheme.neonGreen.withOpacity(0.2)
                        : Colors.black.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _selectedDeviceType == 2 
                          ? AppTheme.neonGreen 
                          : Colors.white.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        Icons.tablet_mac,
                        color: _selectedDeviceType == 2 
                            ? AppTheme.neonGreen 
                            : Colors.white70,
                        size: 32,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Device 2',
                        style: TextStyle(
                          color: _selectedDeviceType == 2 
                              ? AppTheme.neonGreen 
                              : Colors.white70,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Last 12 words',
                        style: TextStyle(
                          color: _selectedDeviceType == 2 
                              ? AppTheme.neonGreen.withOpacity(0.8)
                              : Colors.white54,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text('Import Device'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.black,
              AppTheme.darkBackgroundSecondary,
              Colors.black,
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Spacer(),
                
                // Title
                const Text(
                  'Import Your Device',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                
                const SizedBox(height: 16),
                
                const Text(
                  'Select your device type and enter your 12-word recovery phrase',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                  textAlign: TextAlign.center,
                ),
                
                const SizedBox(height: 32),
                
                // Device Selector
                _buildDeviceSelector(),
                
                const SizedBox(height: 24),
                
                // Mnemonic Input
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _errorMessage != null 
                          ? Colors.red 
                          : AppTheme.neonGreen.withOpacity(0.3),
                    ),
                  ),
                  child: TextField(
                    controller: _mnemonicController,
                    maxLines: 3,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: _selectedDeviceType == 1 
                          ? 'Enter your first 12 words...'
                          : _selectedDeviceType == 2
                              ? 'Enter your last 12 words...'
                              : 'Select device type first...',
                      hintStyle: const TextStyle(color: Colors.white54),
                      border: InputBorder.none,
                    ),
                    enabled: !_isLoading && _selectedDeviceType != null,
                  ),
                ),
                
                if (_errorMessage != null) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.red.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error, color: Colors.red, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _errorMessage!,
                            style: const TextStyle(color: Colors.red),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                
                const SizedBox(height: 32),
                
                // Verify Button
                ElevatedButton(
                  onPressed: _isLoading || _selectedDeviceType == null 
                      ? null 
                      : _verifyDeviceMnemonic,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.neonGreen,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 8,
                  ),
                  child: _isLoading
                      ? const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.black),
                              ),
                            ),
                            SizedBox(width: 12),
                            Text(
                              'Verifying Device...',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        )
                      : const Text(
                          'Verify Device',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
                
                const Spacer(),
                
                // Info Box
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white.withOpacity(0.1)),
                  ),
                  child: const Column(
                    children: [
                      Row(
                        children: [
                          Icon(Icons.security, color: AppTheme.neonGreen),
                          SizedBox(width: 8),
                          Text(
                            'Device Verification',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Each device stores only half of your recovery phrase. Select your device type and enter your 12-word portion to verify and access your wallet.',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
