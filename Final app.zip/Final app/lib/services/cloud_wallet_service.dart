import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/transaction.dart';

class CloudWalletService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // Collection names
  static const String _walletsCollection = 'wallets';
  static const String _transactionsSubcollection = 'transactions';
  static const String _devicesSubcollection = 'devices';

  // ==================== MNEMONIC HASHING ====================
  
  /// Hash mnemonic for secure storage and lookup (never store plain mnemonic!)
  static String hashMnemonic(String mnemonic) {
    // CRITICAL: Normalize mnemonic EXACTLY the same way every time
    final normalizedMnemonic = mnemonic
        .trim()                           // Remove leading/trailing spaces
        .toLowerCase()                    // Convert to lowercase
        .replaceAll(RegExp(r'\s+'), ' '); // Replace multiple spaces with single space
    
    final hash = sha256.convert(utf8.encode(normalizedMnemonic)).toString();
    
    // Debug logging - ALWAYS log this for troubleshooting
    print('🔑 CloudWalletService.hashMnemonic:');
    print('  📝 Original: "$mnemonic"');
    print('  🔧 Normalized: "$normalizedMnemonic"');
    print('  🏷️ Hash (DocID): $hash');
    
    return hash;
  }

  /// Verify if a mnemonic matches a stored hash
  static bool verifyMnemonicHash(String mnemonic, String storedHash) {
    return hashMnemonic(mnemonic) == storedHash;
  }

  // ==================== WALLET CREATION ====================

  /// Debug helper to verify document ID generation
  static void debugDocumentId(String mnemonic, String operation) {
    final docId = hashMnemonic(mnemonic);
    print('🔍 $operation - Document ID: $docId');
  }
  
  /// Save a new wallet to Firestore (called when creating wallet)
  static Future<bool> saveWalletToFirestore({
    required String mnemonic,
    required String walletAddress,
    required String publicKey,
    required Map<String, dynamic> additionalData,
  }) async {
    try {
      print('🔄 CloudWalletService.saveWalletToFirestore called');
      debugDocumentId(mnemonic, 'CREATE_SAVE');
      
      final mnemonicHash = hashMnemonic(mnemonic);
      print('💾 Saving to document ID: $mnemonicHash');
      
      // Check if wallet already exists
      final existingWallet = await getWalletFromFirestore(mnemonic);
      if (existingWallet != null) {
        print('⚠️ Wallet already exists in Firestore');
        return false; // Wallet already exists
      }

      // Create wallet document
      await _firestore.collection(_walletsCollection).doc(mnemonicHash).set({
        'walletAddress': walletAddress,
        'publicKey': publicKey,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'isActive': true,
        'deviceCount': 0,
        'transactionCount': 0,
        'lastAccessedAt': FieldValue.serverTimestamp(),
        'additionalData': additionalData,
        // Never store the actual mnemonic - only the hash as document ID
      }, SetOptions(merge: false));

      print('✅ Wallet saved to Firestore successfully');
      return true;
    } catch (e) {
      print('💥 Error saving wallet to Firestore: $e');
      return false;
    }
  }

  // ==================== WALLET IMPORT/RETRIEVAL ====================
  
  /// Get wallet data from Firestore (called when importing wallet)
  static Future<Map<String, dynamic>?> getWalletFromFirestore(String mnemonic) async {
    try {
      print('🔄 CloudWalletService.getWalletFromFirestore called');
      debugDocumentId(mnemonic, 'IMPORT_LOOKUP');
      
      final mnemonicHash = hashMnemonic(mnemonic);
      print('🔍 Looking for document with ID: $mnemonicHash');
      
      DocumentSnapshot doc = await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .get();
  
      print('📄 Document exists: ${doc.exists}');
      if (doc.exists) {
        print('📊 Document data keys: ${(doc.data() as Map<String, dynamic>?)?.keys.toList()}');
      }
      
      if (doc.exists && doc.data() != null) {
        final data = doc.data() as Map<String, dynamic>;
        
        // Validate required fields
        if (data['walletAddress'] == null) {
          print('❌ Invalid wallet data: missing walletAddress');
          return null;
        }
        
        // Update last accessed timestamp
        await _updateLastAccessed(mnemonicHash);
        
        print('✅ Wallet found in Firestore successfully');
        return {
          'walletAddress': data['walletAddress'],
          'publicKey': data['publicKey'] ?? '',
          'createdAt': data['createdAt'],
          'updatedAt': data['updatedAt'],
          'deviceCount': data['deviceCount'] ?? 0,
          'transactionCount': data['transactionCount'] ?? 0,
          'additionalData': data['additionalData'] ?? {},
          'mnemonicHash': mnemonicHash, // Include hash for future operations
        };
      }
    
      print('❌ Wallet not found in Firestore - document does not exist or has no data');
      return null;
    } catch (e) {
      print('💥 Error getting wallet from Firestore: $e');
      return null;
    }
  }

  /// Check if a wallet exists without retrieving full data
  static Future<bool> walletExistsInFirestore(String mnemonic) async {
    try {
      final mnemonicHash = hashMnemonic(mnemonic);
      DocumentSnapshot doc = await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .get();
      return doc.exists;
    } catch (e) {
      print('Error checking wallet existence: $e');
      return false;
    }
  }

  // ==================== DEVICE-SPECIFIC VERIFICATION ====================

  /// Verify device-specific mnemonic part against all wallets in Firestore
  static Future<Map<String, dynamic>?> verifyDeviceMnemonicPart({
    required String mnemonicPart,
    required int deviceType, // 1 or 2
  }) async {
    try {
      print('🔍 CloudWalletService.verifyDeviceMnemonicPart called');
      print('📝 Input mnemonic part: "$mnemonicPart"');
      print('📱 Device type: $deviceType');
      
      // Validate input - ensure exactly 12 words
      final words = mnemonicPart.trim().split(' ');
      if (words.length != 12) {
        print('❌ Invalid mnemonic part length: ${words.length}');
        return null;
      }
      
      // Normalize the input mnemonic part
      final normalizedInput = mnemonicPart.trim().toLowerCase();
      print('🔧 Normalized input: "$normalizedInput"');
      
      // Get all wallets from Firestore
      QuerySnapshot walletsSnapshot = await _firestore
          .collection(_walletsCollection)
          .get();
      
      print('📊 Found ${walletsSnapshot.docs.length} wallets to check');
      
      for (var walletDoc in walletsSnapshot.docs) {
        try {
          final walletData = walletDoc.data() as Map<String, dynamic>;
          final mnemonicHash = walletDoc.id;
          
          print('🔍 Checking wallet: ${walletData['walletAddress']}');
          
          // Get devices for this wallet
          QuerySnapshot devicesSnapshot = await _firestore
              .collection(_walletsCollection)
              .doc(mnemonicHash)
              .collection(_devicesSubcollection)
              .where('deviceType', isEqualTo: deviceType)
              .where('isActive', isEqualTo: true)
              .get();
          
          print('📱 Found ${devicesSnapshot.docs.length} devices of type $deviceType for this wallet');
          
          for (var deviceDoc in devicesSnapshot.docs) {
            final deviceData = deviceDoc.data() as Map<String, dynamic>;
            final storedMnemonicPart = deviceData['mnemonicPart'] as String?;
            
            if (storedMnemonicPart != null) {
              final normalizedStored = storedMnemonicPart.trim().toLowerCase();
              print('🔍 Comparing:');
              print('  Input:  "$normalizedInput"');
              print('  Stored: "$normalizedStored"');
              print('  Match:  ${normalizedInput == normalizedStored}');
              
              if (normalizedInput == normalizedStored) {
                print('✅ Device mnemonic part verified for wallet: ${walletData['walletAddress']}');
                
                return {
                  'walletAddress': walletData['walletAddress'],
                  'publicKey': walletData['publicKey'] ?? '',
                  'mnemonicHash': mnemonicHash,
                  'deviceId': deviceDoc.id,
                  'deviceType': deviceType,
                  'walletData': walletData,
                  'deviceData': deviceData,
                };
              }
            } else {
              print('⚠️ Device has no mnemonic part stored');
            }
          }
        } catch (e) {
          print('Error checking wallet ${walletDoc.id}: $e');
          continue;
        }
      }
      
      print('❌ No matching device mnemonic part found');
      return null;
    } catch (e) {
      print('💥 Error verifying device mnemonic part: $e');
      return null;
    }
  }

  /// Store device mnemonic part when registering device
  static Future<bool> registerDeviceWithMnemonicPart({
    required String mnemonic,
    required String deviceId,
    required String deviceName,
    required int deviceType,
    required String mnemonicPart,
    required String password,
    required String transactionPassword,
    required Map<String, dynamic> deviceInfo,
  }) async {
    print('🔄 CloudWalletService.registerDeviceWithMnemonicPart called');
    print('📱 Device ID: $deviceId');
    print('📱 Device Name: $deviceName');
    print('📱 Device Type: $deviceType');
    print('🔑 Password provided: ${password.isNotEmpty}');
    print('🔑 Transaction password provided: ${transactionPassword.isNotEmpty}');
    print('📝 Mnemonic part preview: ${mnemonicPart.split(' ').take(3).join(' ')}...');
    
    try {
      final mnemonicHash = hashMnemonic(mnemonic);
      
      // Verify the mnemonic part is exactly 12 words
      final words = mnemonicPart.trim().split(' ');
      if (words.length != 12) {
        print('❌ Error: Mnemonic part must be exactly 12 words, got ${words.length}');
        return false;
      }
      
      print('💾 Saving device to Firebase...');
      print('📍 Collection: $_walletsCollection');
      print('📍 Document: $mnemonicHash');
      print('📍 Subcollection: $_devicesSubcollection');
      print('📍 Device Document: $deviceId');
      
      // Add device to subcollection with mnemonic part and passwords
      await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .collection(_devicesSubcollection)
          .doc(deviceId)
          .set({
        'deviceId': deviceId,
        'deviceName': deviceName,
        'deviceType': deviceType,
        'mnemonicPart': mnemonicPart,
        'password': password,
        'transactionPassword': transactionPassword,
        'deviceInfo': deviceInfo,
        'registeredAt': FieldValue.serverTimestamp(),
        'lastSeenAt': FieldValue.serverTimestamp(),
        'isActive': true,
      }, SetOptions(merge: true));

      print('✅ Device document created successfully');

      // Update device count in main wallet document
      await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .update({
        'deviceCount': FieldValue.increment(1),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      print('✅ Device $deviceType ($deviceName) registered successfully with ${words.length} words and passwords');
      return true;
    } catch (e) {
      print('💥 Error registering device with mnemonic part: $e');
      print('💥 Stack trace: ${StackTrace.current}');
      return false;
    }
  }

  // ==================== TRANSACTION MANAGEMENT ====================
  
  /// Add a transaction to Firestore
  static Future<bool> addTransactionToFirestore({
    required String mnemonic,
    required WalletTransaction transaction,
  }) async {
    try {
      final mnemonicHash = hashMnemonic(mnemonic);
      
      // Add transaction to subcollection
      await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .collection(_transactionsSubcollection)
          .doc(transaction.id)
          .set(transaction.toJson(), SetOptions(merge: true));

      // Update transaction count in main wallet document
      await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .update({
        'transactionCount': FieldValue.increment(1),
        'updatedAt': FieldValue.serverTimestamp(),
        'lastTransactionAt': FieldValue.serverTimestamp(),
      });

      print('Transaction added to Firestore: ${transaction.id}');
      return true;
    } catch (e) {
      print('Error adding transaction to Firestore: $e');
      return false;
    }
  }

  /// Update a transaction in Firestore
  static Future<bool> updateTransactionInFirestore({
    required String mnemonic,
    required String transactionId,
    required Map<String, dynamic> updates,
  }) async {
    try {
      final mnemonicHash = hashMnemonic(mnemonic);
      
      await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .collection(_transactionsSubcollection)
          .doc(transactionId)
          .update({
        ...updates,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      print('Transaction updated in Firestore: $transactionId');
      return true;
    } catch (e) {
      print('Error updating transaction in Firestore: $e');
      return false;
    }
  }

  /// Get all transactions for a wallet
  static Future<List<WalletTransaction>> getWalletTransactions(String mnemonic, {int limit = 100}) async {
    try {
      final mnemonicHash = hashMnemonic(mnemonic);
      
      QuerySnapshot snapshot = await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .collection(_transactionsSubcollection)
          .orderBy('timestamp', descending: true)
          .limit(limit)
          .get();

      List<WalletTransaction> transactions = [];
      for (var doc in snapshot.docs) {
        try {
          final data = doc.data() as Map<String, dynamic>;
          transactions.add(WalletTransaction.fromJson(data));
        } catch (e) {
          print('Error parsing transaction ${doc.id}: $e');
        }
      }

      return transactions;
    } catch (e) {
      print('Error getting wallet transactions: $e');
      return [];
    }
  }

  /// Update device last seen timestamp
  static Future<void> updateDeviceLastSeen(String mnemonic, String deviceId) async {
    try {
      final mnemonicHash = hashMnemonic(mnemonic);
      
      await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .collection(_devicesSubcollection)
          .doc(deviceId)
          .update({
        'lastSeenAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error updating device last seen: $e');
    }
  }

  /// Get wallet statistics
  static Future<Map<String, dynamic>> getWalletStats(String mnemonic) async {
    try {
      final mnemonicHash = hashMnemonic(mnemonic);
      
      // Get main wallet document
      DocumentSnapshot walletDoc = await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .get();

      if (!walletDoc.exists) {
        return {};
      }

      final walletData = walletDoc.data() as Map<String, dynamic>;

      return {
        'walletAddress': walletData['walletAddress'],
        'createdAt': walletData['createdAt'],
        'deviceCount': walletData['deviceCount'] ?? 0,
        'transactionCount': walletData['transactionCount'] ?? 0,
        'lastAccessedAt': walletData['lastAccessedAt'],
      };
    } catch (e) {
      print('Error getting wallet stats: $e');
      return {};
    }
  }

  /// Get all devices for a wallet
  static Future<List<Map<String, dynamic>>> getWalletDevices(String mnemonic) async {
    try {
      final mnemonicHash = hashMnemonic(mnemonic);
      
      QuerySnapshot snapshot = await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .collection(_devicesSubcollection)
          .where('isActive', isEqualTo: true)
          .orderBy('registeredAt', descending: true)
          .get();

      return snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        data['id'] = doc.id;
        return data;
      }).toList();
    } catch (e) {
      print('Error getting wallet devices: $e');
      return [];
    }
  }

  /// Sync local wallet data with cloud
  static Future<bool> syncWalletWithCloud({
    required String mnemonic,
    required List<WalletTransaction> localTransactions,
  }) async {
    try {
      final cloudTransactions = await getWalletTransactions(mnemonic);
      final cloudTransactionIds = cloudTransactions.map((tx) => tx.id).toSet();
      
      // Upload local transactions that don't exist in cloud
      for (var localTx in localTransactions) {
        if (!cloudTransactionIds.contains(localTx.id)) {
          await addTransactionToFirestore(
            mnemonic: mnemonic,
            transaction: localTx,
          );
        }
      }
      
      print('Wallet synced with cloud successfully');
      return true;
    } catch (e) {
      print('Error syncing wallet with cloud: $e');
      return false;
    }
  }

  /// Test cloud wallet service connection
  static Future<bool> testConnection() async {
    try {
      // Try to write a test document
      await _firestore
          .collection('test_cloud_wallet')
          .add({
        'test': true,
        'timestamp': FieldValue.serverTimestamp(),
      });
      
      print('Cloud wallet service connection successful');
      return true;
    } catch (e) {
      print('Cloud wallet service connection failed: $e');
      return false;
    }
  }

  /// Update last accessed timestamp
  static Future<void> _updateLastAccessed(String mnemonicHash) async {
    try {
      await _firestore
          .collection(_walletsCollection)
          .doc(mnemonicHash)
          .update({
        'lastAccessedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error updating last accessed: $e');
    }
  }
}
