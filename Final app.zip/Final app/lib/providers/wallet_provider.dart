import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web3_wallet/utils/secure_storage.dart';
import 'package:web3_wallet/utils/wallet_api.dart';
import 'package:web3_wallet/models/transaction.dart';
import 'package:web3_wallet/services/cloud_wallet_service.dart';
import 'package:bip39/bip39.dart' as bip39;
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'dart:math' as math;

class WalletProvider with ChangeNotifier {
  final SecureStorage _secureStorage = SecureStorage();
  
  String _walletAddress = '';
  String _userId = '';
  String _mnemonic = '';
  bool _isDevice1 = true;
  List<WalletTransaction> _transactions = [];
  bool _isInitialized = false;
  bool _isCloudSynced = false;

  // Getters
  String get walletAddress => _walletAddress;
  String get userId => _userId;
  String get mnemonic => _mnemonic;
  bool get isDevice1 => _isDevice1;
  List<WalletTransaction> get transactions => _transactions;
  bool get isInitialized => _isInitialized;
  bool get isCloudSynced => _isCloudSynced;

  // ==================== INITIALIZATION ====================
  
  Future<void> initialize() async {
    try {
      _walletAddress = await _secureStorage.getWalletAddress() ?? '';
      _userId = await _secureStorage.getUserId() ?? _generateUserId();
      _mnemonic = await _secureStorage.getMnemonic() ?? '';
      
      if (await _secureStorage.getUserId() == null) {
        await _secureStorage.saveUserId(_userId);
      }
      
      _isDevice1 = await _secureStorage.getDeviceType();
      await _loadTransactions();
      _isInitialized = await _secureStorage.getWalletInitialized();
      
      // Sync with cloud if wallet exists
      if (_isInitialized && _mnemonic.isNotEmpty) {
        await _syncWithCloud();
      }
      
      notifyListeners();
    } catch (e) {
      print('Error initializing wallet provider: $e');
    }
  }

  // ==================== CLOUD SYNCHRONIZATION ====================
  
  Future<void> _syncWithCloud() async {
    try {
      if (_mnemonic.isEmpty) {
        print('No mnemonic available for cloud sync');
        return;
      }
      
      // Check if wallet exists in cloud
      final cloudWallet = await CloudWalletService.getWalletFromFirestore(_mnemonic);
      
      if (cloudWallet != null) {
        // Wallet exists in cloud - sync data
        print('Syncing with existing cloud wallet');
        
        // Update local wallet address if different
        final cloudAddress = cloudWallet['walletAddress'] as String;
        if (_walletAddress != cloudAddress) {
          _walletAddress = cloudAddress;
          await _secureStorage.saveWalletAddress(_walletAddress);
        }
        
        // Sync transactions
        await CloudWalletService.syncWalletWithCloud(
          mnemonic: _mnemonic,
          localTransactions: _transactions,
        );
        
        // Load latest transactions from cloud
        final cloudTransactions = await CloudWalletService.getWalletTransactions(_mnemonic);
        _mergeTransactions(cloudTransactions);
        
        // Register this device
        await _registerDeviceInCloud();
        
        _isCloudSynced = true;
      } else {
        print('Wallet not found in cloud - will create on next wallet creation');
        _isCloudSynced = false;
      }
      
      notifyListeners();
    } catch (e) {
      print('Error syncing with cloud: $e');
      _isCloudSynced = false;
    }
  }

  Future<void> _registerDeviceInCloud() async {
    try {
      if (_mnemonic.isEmpty) return;
      
      final deviceId = await _secureStorage.getDeviceId() ?? _generateDeviceId();
      await _secureStorage.storeDeviceId(deviceId);
      
      // Get the device-specific mnemonic part
      final mnemonicPart = _isDevice1 
          ? await _secureStorage.getDevice1MnemonicPart()
          : await _secureStorage.getDevice2MnemonicPart();
      
      if (mnemonicPart == null) {
        print('Warning: No mnemonic part found for device registration');
        return;
      }
      
      // Get passwords
      final password = _isDevice1 
          ? await _secureStorage.getDevice1Password()
          : await _secureStorage.getDevice2Password();
      
      final transactionPassword = _isDevice1 
          ? await _secureStorage.getDevice1TransactionPassword()
          : await _secureStorage.getDevice2TransactionPassword();
      
      if (password == null || transactionPassword == null) {
        print('Warning: No passwords found for device registration');
        return;
      }
      
      await CloudWalletService.registerDeviceWithMnemonicPart(
        mnemonic: _mnemonic,
        deviceId: deviceId,
        deviceName: _isDevice1 ? 'Device 1' : 'Device 2',
        deviceType: _isDevice1 ? 1 : 2,
        mnemonicPart: mnemonicPart,
        password: password,
        transactionPassword: transactionPassword,
        deviceInfo: {
          'platform': 'flutter',
          'registeredAt': DateTime.now().toIso8601String(),
          'userId': _userId,
        },
      );
      
      // Update device last seen periodically
      await CloudWalletService.updateDeviceLastSeen(_mnemonic, deviceId);
    } catch (e) {
      print('Error registering device in cloud: $e');
    }
  }

  // ==================== WALLET CREATION ====================
  
  Future<bool> createWallet(
    String mnemonic,
    String device1Password,
    String device1TxPassword,
    String device2Password,
    String device2TxPassword,
  ) async {
    try {
      print('🔄 WalletProvider.createWallet called');
      
      // Check if wallet already exists in cloud
      final existsInCloud = await CloudWalletService.walletExistsInFirestore(mnemonic);
      if (existsInCloud) {
        print('❌ Wallet already exists in cloud - use import instead');
        return false;
      }
      
      // Generate wallet from mnemonic
      final walletData = await WalletApi.createWalletFromMnemonic(mnemonic);
      print('✅ Generated wallet address: ${walletData['address']}');
      
      // Store all data through SecureStorage
      await _secureStorage.saveWalletAddress(walletData['address']!);
      await _secureStorage.savePrivateKey(walletData['privateKey']!);
      await _secureStorage.saveMnemonic(mnemonic);
      await _secureStorage.savePublicKey(walletData['publicKey'] ?? '');
      
      // Store passwords for BOTH devices
      await _secureStorage.storeDevice1Password(device1Password);
      await _secureStorage.storeDevice1TransactionPassword(device1TxPassword);
      await _secureStorage.storeDevice2Password(device2Password);
      await _secureStorage.storeDevice2TransactionPassword(device2TxPassword);
      
      // Split and store mnemonic parts
      final splitParts = splitMnemonic(mnemonic);
      await _secureStorage.storeDevice1MnemonicPart(splitParts['device1']!);
      await _secureStorage.storeDevice2MnemonicPart(splitParts['device2']!);
      
      // Mark as initialized
      await _secureStorage.storeWalletInitialized(true);
      
      _walletAddress = walletData['address']!;
      _mnemonic = mnemonic;
      _isInitialized = true;
      
      print('💾 Saving wallet to Firebase...');
      
      // Save wallet to cloud
      final cloudSaved = await CloudWalletService.saveWalletToFirestore(
        mnemonic: mnemonic,
        walletAddress: _walletAddress,
        publicKey: walletData['publicKey'] ?? '',
        additionalData: {
          'created_by_device': _isDevice1 ? 1 : 2,
          'created_by_user': _userId,
          'app_version': '1.0.0',
        },
      );
      
      if (cloudSaved) {
        print('✅ Wallet saved to Firebase');
        
        // Register BOTH devices in Firebase with correct device types
        final device1Success = await _registerSpecificDeviceInCloud(
          deviceType: 1,
          deviceName: 'Device 1',
          mnemonicPart: splitParts['device1']!,
          password: device1Password,
          transactionPassword: device1TxPassword,
        );
        
        final device2Success = await _registerSpecificDeviceInCloud(
          deviceType: 2,
          deviceName: 'Device 2',
          mnemonicPart: splitParts['device2']!,
          password: device2Password,
          transactionPassword: device2TxPassword,
        );
        
        print('✅ Device 1 registration: $device1Success');
        print('✅ Device 2 registration: $device2Success');
        
        _isCloudSynced = true;
        print('✅ Wallet created and saved to cloud successfully');
      } else {
        print('❌ Wallet created locally but failed to save to cloud');
        _isCloudSynced = false;
      }
      
      // Clear temp mnemonic
      await _secureStorage.clearTempFullMnemonic();
      
      notifyListeners();
      return true;
    } catch (e) {
      print('💥 Error creating wallet: $e');
      return false;
    }
  }

  Future<bool> _registerSpecificDeviceInCloud({
    required int deviceType,
    required String deviceName,
    required String mnemonicPart,
    required String password,
    required String transactionPassword,
  }) async {
    try {
      final deviceId = _generateDeviceId();
      
      print('🔄 Registering $deviceName (Type: $deviceType)...');
      print('📱 Device ID: $deviceId');
      print('🔑 Password: $password');
      print('🔑 Transaction Password: $transactionPassword');
      print('📝 Mnemonic part preview: ${mnemonicPart.split(' ').take(3).join(' ')}...');
      
      final success = await CloudWalletService.registerDeviceWithMnemonicPart(
        mnemonic: _mnemonic,
        deviceId: deviceId,
        deviceName: deviceName,
        deviceType: deviceType,
        mnemonicPart: mnemonicPart,
        password: password,
        transactionPassword: transactionPassword,
        deviceInfo: {
          'platform': 'flutter',
          'registeredAt': DateTime.now().toIso8601String(),
          'userId': _userId,
        },
      );
      
      // Store the device ID for the current device
      if ((_isDevice1 && deviceType == 1) || (!_isDevice1 && deviceType == 2)) {
        await _secureStorage.storeDeviceId(deviceId);
        print('💾 Stored device ID for current device');
      }
      
      return success;
    } catch (e) {
      print('💥 Error registering $deviceName: $e');
      return false;
    }
  }

  // ==================== WALLET CREATION FLOW METHODS ====================

  Future<void> initializeWalletCreation(String fullMnemonic) async {
    try {
      // Store the full mnemonic temporarily for the creation process
      await _secureStorage.storeTempFullMnemonic(fullMnemonic);
      _mnemonic = fullMnemonic;
      notifyListeners();
      print('Wallet creation initialized with mnemonic');
    } catch (e) {
      print('Error initializing wallet creation: $e');
    }
  }

  Future<bool> finalizeWalletCreation(
    String device1Mnemonic,
    String device2Mnemonic,
    String device1Password,
    String device2Password,
    String device1TxPassword,
  ) async {
    try {
      // Get the stored temporary full mnemonic instead of combining parts
      final fullMnemonic = await _secureStorage.getTempFullMnemonic();
      if (fullMnemonic == null || fullMnemonic.isEmpty) {
        print('Error: No temporary full mnemonic found');
        return false;
      }

      // Validate it's exactly 24 words
      final words = fullMnemonic.trim().split(' ');
      if (words.length != 24) {
        print('Error: Invalid mnemonic length: ${words.length} words');
        return false;
      }

      print('Using stored full mnemonic with ${words.length} words');

      // For now, we'll use the device1TxPassword for both devices
      // You can modify this if you need separate transaction passwords
      final device2TxPassword = device1TxPassword; // or get from UI if needed

      // Create wallet using existing logic
      final success = await createWallet(
        fullMnemonic,
        device1Password,
        device1TxPassword,
        device2Password,
        device2TxPassword,
      );

      if (success) {
        print('Wallet creation finalized successfully');
      } else {
        print('Failed to finalize wallet creation');
      }

      return success;
    } catch (e) {
      print('Error finalizing wallet creation: $e');
      return false;
    }
  }

  // ==================== WALLET IMPORT ====================
  
  Future<bool> importWallet(String mnemonic) async {
    try {
      print('WalletProvider.importWallet called');
      print('Input mnemonic: "$mnemonic"');
      print('Mnemonic length: ${mnemonic.split(' ').length} words');
      
      // Get wallet from cloud
      final cloudWallet = await CloudWalletService.getWalletFromFirestore(mnemonic);
      
      print('CloudWallet result: $cloudWallet');
      
      if (cloudWallet == null) {
        print('Wallet not found in cloud - this should trigger wallet creation flow');
        return false;
      }
      
      print('Wallet found in cloud! Proceeding with import...');
      
      // Generate wallet data from mnemonic to get private key
      final walletData = await WalletApi.createWalletFromMnemonic(mnemonic);
      print('Generated wallet address from mnemonic: ${walletData['address']}');
      
      // Verify the wallet address matches
      final cloudAddress = cloudWallet['walletAddress'] as String;
      print('Cloud wallet address: $cloudAddress');
      
      if (walletData['address'] != cloudAddress) {
        print('ERROR: Wallet address mismatch!');
        print('  Generated: ${walletData['address']}');
        print('  Cloud: $cloudAddress');
        return false;
      }
      
      print('Address verification successful - proceeding with import');
      
      // Store wallet data locally
      await _secureStorage.saveWalletAddress(cloudAddress);
      await _secureStorage.savePrivateKey(walletData['privateKey']!);
      await _secureStorage.saveMnemonic(mnemonic);
      await _secureStorage.savePublicKey(cloudWallet['publicKey'] ?? '');
      await _secureStorage.storeWalletInitialized(true);
      
      _walletAddress = cloudAddress;
      _mnemonic = mnemonic;
      _isInitialized = true;
      
      // Load transactions from cloud
      final cloudTransactions = await CloudWalletService.getWalletTransactions(mnemonic);
      print('Loaded ${cloudTransactions.length} transactions from cloud');
      _transactions = cloudTransactions;
      await _saveTransactions();
      
      // Register this device
      await _registerDeviceInCloud();
      _isCloudSynced = true;
      
      print('Wallet imported successfully from cloud');
      notifyListeners();
      return true;
    } catch (e) {
      print('Error importing wallet: $e');
      print('Stack trace: ${StackTrace.current}');
      return false;
    }
  }

  // ==================== DEVICE-SPECIFIC VERIFICATION ====================

  /// Verify device mnemonic part and prepare for login
  Future<Map<String, dynamic>?> verifyDeviceMnemonicPart({
    required String mnemonicPart,
    required int deviceType,
  }) async {
    try {
      print('🔄 WalletProvider.verifyDeviceMnemonicPart called');
      print('📝 Mnemonic part preview: "${mnemonicPart.substring(0, math.min(10, mnemonicPart.length))}..."');
      print('📱 Device type: $deviceType');
      
      // Verify against cloud using the updated method
      final verificationResult = await CloudWalletService.verifyDeviceMnemonicPart(
        mnemonicPart: mnemonicPart,
        deviceType: deviceType,
      );
      
      if (verificationResult == null) {
        print('❌ Device mnemonic part verification failed');
        return null;
      }
      
      print('✅ Device mnemonic part verified successfully');
      print('🔍 Verification result: $verificationResult');
      
      // Store temporary verification data for login process
      await _secureStorage.write('temp_verification_data', jsonEncode(verificationResult));
      await _secureStorage.write('temp_mnemonic_part', mnemonicPart);
      await _secureStorage.storeDeviceType(deviceType == 1);
      
      _isDevice1 = (deviceType == 1);
      
      return verificationResult;
    } catch (e) {
      print('💥 Error verifying device mnemonic part: $e');
      return null;
    }
  }

  /// Complete device login after password verification
  Future<bool> completeDeviceLogin(String password) async {
    try {
      print('🔄 WalletProvider.completeDeviceLogin called');
      
      // Get temporary verification data
      final tempDataJson = await _secureStorage.read('temp_verification_data');
      if (tempDataJson == null) {
        print('❌ No temporary verification data found');
        return false;
      }
      
      final verificationData = jsonDecode(tempDataJson);
      final mnemonicHash = verificationData['mnemonicHash'] as String;
      final walletAddress = verificationData['walletAddress'] as String;
      final deviceType = verificationData['deviceType'] as int;
      final deviceData = verificationData['deviceData'] as Map<String, dynamic>;
      
      print('🔍 Device data from verification: $deviceData');
      
      // Get the stored password from Firebase device data
      final storedPassword = deviceData['password'] as String?;
      
      print('🔑 Firebase stored password: "$storedPassword"');
      print('🔑 Input password: "$password"');
      print('🔑 Passwords match: ${storedPassword == password}');
      
      if (storedPassword == null || storedPassword.isEmpty) {
        print('❌ No password found in Firebase device data');
        return false;
      }
      
      if (storedPassword != password) {
        print('❌ Password verification failed');
        return false;
      }
      
      print('✅ Password verified successfully against Firebase');
      
      // Store wallet data locally
      await _secureStorage.saveWalletAddress(walletAddress);
      await _secureStorage.savePublicKey(verificationData['publicKey'] ?? '');
      await _secureStorage.storeWalletInitialized(true);
      
      // Store device-specific data locally for future use
      final mnemonicPart = await _secureStorage.read('temp_mnemonic_part');
      if (mnemonicPart != null) {
        if (deviceType == 1) {
          await _secureStorage.storeDevice1MnemonicPart(mnemonicPart);
          await _secureStorage.storeDevice1Password(password);
          if (deviceData['transactionPassword'] != null) {
            await _secureStorage.storeDevice1TransactionPassword(deviceData['transactionPassword']);
          }
        } else {
          await _secureStorage.storeDevice2MnemonicPart(mnemonicPart);
          await _secureStorage.storeDevice2Password(password);
          if (deviceData['transactionPassword'] != null) {
            await _secureStorage.storeDevice2TransactionPassword(deviceData['transactionPassword']);
          }
        }
      }
      
      // Update provider state
      _walletAddress = walletAddress;
      _isDevice1 = (deviceType == 1);
      _isInitialized = true;
      
      // Load device-specific transactions and pending approvals
      await _loadDeviceSpecificTransactions(mnemonicHash);
      
      // Update device last seen in cloud
      await CloudWalletService.updateDeviceLastSeen(
        mnemonicHash,
        verificationData['deviceId'],
      );
      
      _isCloudSynced = true;
      
      // Clean up temporary data
      await _secureStorage.delete('temp_verification_data');
      await _secureStorage.delete('temp_mnemonic_part');
      
      print('✅ Device login completed successfully');
      notifyListeners();
      return true;
    } catch (e) {
      print('💥 Error completing device login: $e');
      return false;
    }
  }

  /// Load device-specific transactions and pending approvals
  Future<void> _loadDeviceSpecificTransactions(String mnemonicHash) async {
    try {
      // For now, we'll reconstruct the mnemonic hash to get transactions
      // In a real implementation, you might want to store this differently
      final allTransactions = await CloudWalletService.getWalletTransactions(''); // We need the actual mnemonic
      
      // Filter transactions relevant to this device
      _transactions = allTransactions.where((tx) {
        if (_isDevice1) {
          // Device 1 sees transactions it created or needs to approve
          return !tx.approvedByDevice1 || tx.status == TransactionStatus.pending;
        } else {
          // Device 2 sees transactions it created or needs to approve
          return !tx.approvedByDevice2 || tx.status == TransactionStatus.pending;
        }
      }).toList();
      
      await _saveTransactions();
      print('Loaded ${_transactions.length} device-specific transactions');
    } catch (e) {
      print('Error loading device-specific transactions: $e');
      _transactions = [];
    }
  }

  /// Get pending approvals for current device
  List<WalletTransaction> getPendingApprovalsForDevice() {
    return _transactions.where((tx) {
      if (_isDevice1) {
        return !tx.approvedByDevice1 && 
               (tx.status == TransactionStatus.pending || 
                tx.status == TransactionStatus.approvedByDevice2);
      } else {
        return !tx.approvedByDevice2 && 
               (tx.status == TransactionStatus.pending || 
                tx.status == TransactionStatus.approvedByDevice1);
      }
    }).toList();
  }

  /// Check if device setup is complete for verification
  Future<bool> isDeviceSetupComplete(int deviceType) async {
    try {
      if (deviceType == 1) {
        final password = await _secureStorage.getDevice1Password();
        final txPassword = await _secureStorage.getDevice1TransactionPassword();
        return password != null && txPassword != null;
      } else {
        final password = await _secureStorage.getDevice2Password();
        final txPassword = await _secureStorage.getDevice2TransactionPassword();
        return password != null && txPassword != null;
      }
    } catch (e) {
      print('Error checking device setup: $e');
      return false;
    }
  }

  // ==================== TRANSACTION MANAGEMENT ====================
  
  Future<bool> createTransaction(
    String to,
    String amount,
    String password,
  ) async {
    try {
      // Verify transaction password
      final storedTxPassword = _isDevice1
          ? await _secureStorage.getDevice1TransactionPassword()
          : await _secureStorage.getDevice2TransactionPassword();

      if (storedTxPassword != password) {
        return false;
      }

      // Create new transaction
      final transaction = WalletTransaction(
        id: _generateTransactionId(),
        from: _walletAddress,
        to: to,
        amount: amount,
        timestamp: DateTime.now(),
        status: TransactionStatus.pending,
        approvedByDevice1: _isDevice1,
        approvedByDevice2: !_isDevice1,
      );

      // Save to cloud first
      if (_isCloudSynced && _mnemonic.isNotEmpty) {
        final cloudSaved = await CloudWalletService.addTransactionToFirestore(
          mnemonic: _mnemonic,
          transaction: transaction,
        );
        
        if (!cloudSaved) {
          print('Failed to save transaction to cloud');
          return false;
        }
      }

      // Save locally
      _transactions.add(transaction);
      await _saveTransactions();
      notifyListeners();
      
      return true;
    } catch (e) {
      print('Error creating transaction: $e');
      return false;
    }
  }

  Future<bool> approveTransaction(String transactionId) async {
    try {
      final transactionIndex = _transactions.indexWhere((tx) => tx.id == transactionId);
      if (transactionIndex == -1) return false;

      final transaction = _transactions[transactionIndex];

      // Update approval status
      if (_isDevice1) {
        transaction.approvedByDevice1 = true;
      } else {
        transaction.approvedByDevice2 = true;
      }

      // Update in cloud
      if (_isCloudSynced && _mnemonic.isNotEmpty) {
        await CloudWalletService.updateTransactionInFirestore(
          mnemonic: _mnemonic,
          transactionId: transactionId,
          updates: {
            'approvedByDevice1': transaction.approvedByDevice1,
            'approvedByDevice2': transaction.approvedByDevice2,
            'status': transaction.status.name,
          },
        );
      }

      // Check if both devices have approved
      if (transaction.approvedByDevice1 && transaction.approvedByDevice2) {
        // Execute the transaction
        try {
          final privateKey = await _secureStorage.getPrivateKey();
          if (privateKey != null) {
            final txHash = await WalletApi.sendTransaction(
              privateKey,
              transaction.to,
              transaction.amount,
            );
            
            transaction.txHash = txHash;
            transaction.status = TransactionStatus.completed;
            
            // Update in cloud
            if (_isCloudSynced && _mnemonic.isNotEmpty) {
              await CloudWalletService.updateTransactionInFirestore(
                mnemonic: _mnemonic,
                transactionId: transactionId,
                updates: {
                  'txHash': txHash,
                  'status': TransactionStatus.completed.name,
                },
              );
            }
          }
        } catch (e) {
          print('Error executing transaction: $e');
          transaction.status = TransactionStatus.failed;
          
          // Update failed status in cloud
          if (_isCloudSynced && _mnemonic.isNotEmpty) {
            await CloudWalletService.updateTransactionInFirestore(
              mnemonic: _mnemonic,
              transactionId: transactionId,
              updates: {
                'status': TransactionStatus.failed.name,
                'error': e.toString(),
              },
            );
          }
        }
      } else {
        // Update status based on which device approved
        if (_isDevice1) {
          transaction.status = TransactionStatus.approvedByDevice1;
        } else {
          transaction.status = TransactionStatus.approvedByDevice2;
        }
      }

      _transactions[transactionIndex] = transaction;
      await _saveTransactions();
      notifyListeners();

      return true;
    } catch (e) {
      print('Error approving transaction: $e');
      return false;
    }
  }

  Future<bool> rejectTransaction(String transactionId) async {
    try {
      final transactionIndex = _transactions.indexWhere((tx) => tx.id == transactionId);
      if (transactionIndex == -1) return false;

      // Update status in cloud
      if (_isCloudSynced && _mnemonic.isNotEmpty) {
        await CloudWalletService.updateTransactionInFirestore(
          mnemonic: _mnemonic,
          transactionId: transactionId,
          updates: {
            'status': TransactionStatus.rejected.name,
          },
        );
      }

      _transactions[transactionIndex].status = TransactionStatus.rejected;
      await _saveTransactions();
      notifyListeners();

      return true;
    } catch (e) {
      print('Error rejecting transaction: $e');
      return false;
    }
  }

  Future<void> syncTransactions() async {
    if (_userId.isNotEmpty) {
      final firestoreTransactions = await CloudWalletService.getWalletTransactions(_mnemonic);
      _mergeTransactions(firestoreTransactions);
      await _saveTransactions();
      notifyListeners();
    }
  }

  // ==================== BALANCE MANAGEMENT ====================
  
  Future<String> getWalletBalance({bool forceRefresh = false}) async {
    try {
      if (_walletAddress.isEmpty) {
        _walletAddress = await _secureStorage.getWalletAddress() ?? '';
      }
      
      if (_walletAddress.isEmpty) return '0.0';

      // Try to get cached balance first (unless force refresh)
      if (!forceRefresh) {
        final cachedBalance = await _secureStorage.getWalletBalance();
        final lastBalanceUpdate = await _secureStorage.getLastBalanceUpdate();
        final now = DateTime.now();

        // Use cached balance only if it's less than 30 seconds old
        if (cachedBalance != null && lastBalanceUpdate != null &&
            now.difference(lastBalanceUpdate).inSeconds < 30) {
          return cachedBalance;
        }
      }

      // Otherwise fetch fresh balance
      final balance = await WalletApi.getEthBalance(_walletAddress);

      // Cache the balance using SecureStorage
      await _secureStorage.saveWalletBalance(balance);

      return balance;
    } catch (e) {
      print('Error getting wallet balance: $e');
      // Return cached balance if available
      final cachedBalance = await _secureStorage.getWalletBalance();
      return cachedBalance ?? '0.0';
    }
  }

  // ==================== UTILITY METHODS ====================
  
  void _mergeTransactions(List<WalletTransaction> cloudTransactions) {
    final Map<String, WalletTransaction> mergedMap = {};
    
    // Add local transactions first
    for (var tx in _transactions) {
      mergedMap[tx.id] = tx;
    }
    
    // Override with cloud transactions (more up-to-date)
    for (var tx in cloudTransactions) {
      mergedMap[tx.id] = tx;
    }
    
    _transactions = mergedMap.values.toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  Future<void> _loadTransactions() async {
    try {
      final transactionsJson = await _secureStorage.getTransactions();
      if (transactionsJson != null && transactionsJson.isNotEmpty) {
        final List<dynamic> transactionsList = jsonDecode(transactionsJson);
        _transactions = transactionsList
            .map((json) => WalletTransaction.fromJson(json))
            .toList();
      }
    } catch (e) {
      print('Error loading transactions: $e');
      _transactions = [];
    }
  }

  Future<void> _saveTransactions() async {
    try {
      final transactionsJson = jsonEncode(
        _transactions.map((tx) => tx.toJson()).toList(),
      );
      await _secureStorage.saveTransactions(transactionsJson);
    } catch (e) {
      print('Error saving transactions: $e');
    }
  }

  String generateMnemonic({int strength = 128}) {
    return bip39.generateMnemonic(strength: strength);
  }

  Map<String, String> splitMnemonic(String mnemonic) {
    final words = mnemonic.trim().split(' ');
    
    // Ensure we have exactly 24 words
    if (words.length != 24) {
      throw Exception('Mnemonic must be exactly 24 words, got ${words.length}');
    }
    
    final firstHalf = words.take(12).join(' ');   // First 12 words for device 1
    final secondHalf = words.skip(12).take(12).join(' '); // Next 12 words for device 2
    
    print('Split mnemonic:');
    print('  Device 1 (${firstHalf.split(' ').length} words): ${firstHalf.split(' ').take(3).join(' ')}...');
    print('  Device 2 (${secondHalf.split(' ').length} words): ${secondHalf.split(' ').take(3).join(' ')}...');
    
    return {
      'device1': firstHalf,
      'device2': secondHalf,
    };
  }

  String _generateTransactionId() {
    final random = Random();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final randomNum = random.nextInt(999999);
    return 'tx_${timestamp}_$randomNum';
  }

  String _generateUserId() {
    final random = Random();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final randomNum = random.nextInt(999999);
    return 'user_${timestamp}_$randomNum';
  }

  String _generateDeviceId() {
    final random = Random();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final randomNum = random.nextInt(999999);
    return 'device_${timestamp}_$randomNum';
  }

  // ==================== CLOUD WALLET METHODS ====================
  
  Future<bool> testCloudConnection() async {
    return await CloudWalletService.testConnection();
  }

  Future<Map<String, dynamic>> getWalletStats() async {
    if (_mnemonic.isEmpty) return {};
    return await CloudWalletService.getWalletStats(_mnemonic);
  }

  Future<List<Map<String, dynamic>>> getWalletDevices() async {
    if (_mnemonic.isEmpty) return [];
    return await CloudWalletService.getWalletDevices(_mnemonic);
  }

  Future<void> syncWithCloud() async {
    await _syncWithCloud();
  }

  Future<void> forceCloudSync() async {
    if (_mnemonic.isNotEmpty) {
      await _syncWithCloud();
    }
  }

  // ==================== EXISTING METHODS ====================
  
  void setDeviceType(bool isDevice1) {
    _isDevice1 = isDevice1;
    _secureStorage.storeDeviceType(isDevice1);
    notifyListeners();
  }

  Future<bool> login(String password) async {
    try {
      final storedPassword = _isDevice1 
          ? await _secureStorage.getDevice1Password()
          : await _secureStorage.getDevice2Password();
      
      if (storedPassword == password) {
        await initialize();
        return true;
      }
      return false;
    } catch (e) {
      print('Error during login: $e');
      return false;
    }
  }

  Future<bool> doesWalletExist() async {
    return await _secureStorage.doesWalletExist();
  }

  Future<WalletTransaction?> getTransactionById(String transactionId) async {
    try {
      final localTransaction = _transactions.where((tx) => tx.id == transactionId).firstOrNull;
      if (localTransaction != null) {
        return localTransaction;
      }
      
      // If not found locally and we have cloud sync, check cloud
      if (_isCloudSynced && _mnemonic.isNotEmpty) {
        final cloudTransactions = await CloudWalletService.getWalletTransactions(_mnemonic);
        final cloudTransaction = cloudTransactions.where((tx) => tx.id == transactionId).firstOrNull;
        if (cloudTransaction != null) {
          _transactions.add(cloudTransaction);
          await _saveTransactions();
          notifyListeners();
          return cloudTransaction;
        }
      }
      
      return null;
    } catch (e) {
      print('Error getting transaction by ID: $e');
      return null;
    }
  }

  Future<void> clearAllData() async {
    await _secureStorage.clearAll();
    _walletAddress = '';
    _userId = '';
    _mnemonic = '';
    _isDevice1 = true;
    _transactions = [];
    _isInitialized = false;
    _isCloudSynced = false;
    notifyListeners();
  }

  // Password management methods...
  Future<void> setDevice1Password(String password) async {
    await _secureStorage.storeDevice1Password(password);
  }

  Future<void> setDevice1TransactionPassword(String password) async {
    await _secureStorage.storeDevice1TransactionPassword(password);
  }

  Future<void> setDevice2Password(String password) async {
    await _secureStorage.storeDevice2Password(password);
  }

  Future<void> setDevice2TransactionPassword(String password) async {
    await _secureStorage.storeDevice2TransactionPassword(password);
  }

  Future<String?> getDevice1Password() async {
    return await _secureStorage.getDevice1Password();
  }

  Future<String?> getDevice1TransactionPassword() async {
    return await _secureStorage.getDevice1TransactionPassword();
  }

  Future<String?> getDevice2Password() async {
    return await _secureStorage.getDevice2Password();
  }

  Future<String?> getDevice2TransactionPassword() async {
    return await _secureStorage.getDevice2TransactionPassword();
  }

  Future<String?> getDeviceMnemonicPart(bool isDevice1) async {
    if (isDevice1) {
      return await _secureStorage.getDevice1MnemonicPart();
    } else {
      return await _secureStorage.getDevice2MnemonicPart();
    }
  }

  Future<bool> verifyMnemonicPart(String mnemonicPart) async {
    final storedPart = await getDeviceMnemonicPart(_isDevice1);
    return storedPart == mnemonicPart;
  }

  Future<void> printAllStoredData() async {
    await _secureStorage.printAllKeys();
  }
}
